  <!-- Footer -->
  <footer class="bg-primary py-5">
    <div class="container">
      <div class="small text-center text-white"> <p style="padding-right: 10px;">
      	 &copy;  2019 Mega M / All rights reserved.	
      	 <b style="padding: 10px;font-size: 15px"> | </b>
      	 <a href="POGOJI_UPORABE.pdf" style="color: white" target="_blank">
      	 	Legal notice
      	 </a>
      	 <b style="padding: 10px;font-size: 15px"> | </b> 
      	 <a href="TERMS_AND_CONDITIONS.pdf" style="color: white" target="_blank">
      	 	Terms and conditions
      	 </a>
      	 <b style="padding: 10px;font-size: 15px"> | </b> 
      	 <a href="For_operators.pdf" style="color: white" target="_blank">
      	 	For operators
      	 </a>
      	 
    </div>


  </footer>