<!DOCTYPE html>
<html>
<body >

<?php
header('Location: index.php'); 
?>

</body>
</html>